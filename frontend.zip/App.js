import React, { Component } from 'react';
import {createStackNavigator,createAppContainer } from 'react-navigation';

import LoginScreen from './components/LoginScreen';
import GradeScreen from './components/GradeScreen.js'
import CheckListScreen from './components/CheckListScreen';
import Electricity_UpdateScreen from './components/Electricity_UpdateScreen.js';
import UploadImageScreen from './components/UploadImageScreen';


const MainNavigator = createStackNavigator({
    LoginScreen : {
      screen : LoginScreen
    },
    GradeScreen : {
      screen : GradeScreen
    },
    CheckListScreen : {
        screen : CheckListScreen
    },
    Electricity_UpdateScreen : {
        screen : Electricity_UpdateScreen
    }
    /*
    UploadImageScreen : {
        screen : UploadImageScreen
    },
    */
});



export default createAppContainer(MainNavigator)


class App extends Component {
    render() {
        return (
            <MainNavigator/>
        )
    }
}
