import React from 'react';
import {createStackNavigator,
  createBottomTabNavigator,
  createAppContainer} from 'react-navigation';
  import {
    Ionicons
  } from '@expo/vector-icons';


import {
  Text,
  View,
  TextInput,
  Button,
  StyleSheet,
  FlatList,
  TouchableOpacity
} from 'react-native';
import Client from '../Client.js';
import Electricity_UpdateScreen from './Electricity_UpdateScreen';

// ElectricityScreen 정의
class ElectricityScreen extends React.Component {
  componentDidMount() {
    this.fetchGrade().then(items => {
        this.setState({
            data: items
        })
    });
}

fetchGrade() {
  return fetch('http://192.168.190.16:3000/api/Grade')
      .then(response => response.json())
      .catch(error => {
          console.error(error);
      });
}
constructor(props) {
  super(props);
  this.state = {
      isRefreshing: false
  }
}

render() {
  return (
      <View style={styles.container}>
          <FlatList style={styles.container}
              data={this.state.data}
              renderItem={({ item }) => <TouchableOpacity onPress={() => this.props.navigation.navigate('Electricity_UpdateScreen', { 
                safetycheck_date_prev: item.safetycheck_date, 
                facilityNumber_prev: item.facilityNumber, 
                admin_prev: item.admin, 
                Electricity_prev: item.Electricity, 
                Gas_prev: item.Gas,
                Elevator_prev: item.Elevator,
                Earthquake_resistant_prev: item.Earthquake_resistant,
                Final_prev: item.Final_prev
                })}>
                  <Text style={styles.ElectricityGrade}>
                  Prev_Gas Grade
                  </Text>
                  <Text>
                      {item.Electricity}
                  </Text>
              </TouchableOpacity>}

              ItemSeparatorComponent={() => (
                  <View style={{ height: StyleSheet.hairlineWidth, backgroundColor: 'black' }} />
              )}
              keyExtractor={(item, index) => item.facilityNumber + index}
              refreshing={this.state.isRefreshing}
              onRefresh={() => {
                  this.setState({
                      isRefreshing: true
                  })
                  setTimeout(() => {
                      this.setState({
                          isRefreshing: false
                      })
                      this.fetchGrade()
                  }, 3000);
              }}
          />
      </View>
  );
}
}

const styles = StyleSheet.create({
container: {
  flex: 1,
  backgroundColor: '#fff',
  flexDirection: 'column'
},
ElectricityGrade:{
  fontSize: 20,
  textAlign: 'center',
  margin: 10,
},
});




// GasScreen 정의
class GasScreen extends React.Component {

    constructor() {
      super()
      this.state = {
        Gas: [] // user에 대한 정보를 담기 위한 state
      }
    }
  
    componentWillMount = () => {
      this.getGas()
    }

    getGas = async() => {
      Client.search('Grade') // Client.js에서 
      .then(data => {
        this.setState({
          Gas: data 
        })
      })
    }
  
    render() {
      return(
          <View style={styles2.container}>
            <Button title = "Update safetyCheck List" onPress = { () => this.props.navigation.navigate('CheckListScreen')}/>
            <Button title = "UpLoadImage" onPress = { () => this.props.navigation.navigate('UpLoadImageScreen')}/>
            <Button title = "UpdateGrade" onPress = { () => this.props.navigation.navigate('Electricity_UpdateScreen')}/>
            <Text style={styles2.GasGrade}>
              Prev_Gas Grade
            </Text>
            {this.state.Gas.map((r, i) => (
              <View style={styles2.GasState}
                    key={i}>
            <Text>{r.Gas}</Text>
          </View>
            ))}
        </View>
      )
    }
  }
  
  const styles2=StyleSheet.create({
    container: {
      flex:1,
      justifyContent: 'center',
      alignItems: 'center',
      backgroundColor: '#F5FCFF',
    },
    GasGrade:{
      fontSize: 20,
      textAlign: 'center',
      margin: 10,
    },
    GasState:{
      textAlign: 'center',
      color: '#333333',
      marginBottom: 5,
    },
  });
  



// ElevatorScreen 정의
  class ElevatorScreen extends React.Component {

    constructor() {
      super()
      this.state = {
        Elevator: [] // user에 대한 정보를 담기 위한 state
      }
    }
  
    componentWillMount = () => {
      this.getElevator()
    }
 
    getElevator = async() => {
      Client.search('Grade') // Client.js에서 
      .then(data => {
        this.setState({
            Elevator: data 
        })
      })
    }

    render() {
      return(
          <View style={styles3.container}>
            <Button title = "Update safetyCheck List" onPress = { () => this.props.navigation.navigate('CheckListScreen')}/>
            <Button title = "UpLoadImage" onPress = { () => this.props.navigation.navigate('UpLoadImageScreen')}/>
            <Button title = "UpdateGrade" onPress = { () => this.props.navigation.navigate('Electricity_UpdateScreen')}/>
            <Text style={styles3.ElevatorGrade}>
            Prev_Elevator Grade
            </Text>
            {this.state.Elevator.map((r, i) => (
              <View style={styles3.ElevatorState}
                    key={i}>
            <Text>{r.Elevator}</Text>
          </View>
            ))}
        </View>
      )
    }
  }
  
  const styles3=StyleSheet.create({
    container: {
      flex:1,
      justifyContent: 'center',
      alignItems: 'center',
      backgroundColor: '#F5FCFF',
    },
    ElevatorGrade:{
      fontSize: 20,
      textAlign: 'center',
      margin: 10,
    },
    ElevatorState:{
      textAlign: 'center',
      color: '#333333',
      marginBottom: 5,
    },
  });
  


//Earthquake_resistantScreen 정의
  class Earthquake_resistantScreen extends React.Component {

    constructor() {
      super()
      this.state = {
        Earthquake_resistant: [] // user에 대한 정보를 담기 위한 state
      }
    }
  
    componentWillMount = () => {
      this.getEarthquake_resistant()
    }
  
    getEarthquake_resistant = async() => {
      Client.search('Grade') // Client.js에서 
      .then(data => {
        this.setState({
            Earthquake_resistant: data 
        })
      })
    }
    
    render() {
      return(
          <View style={styles4.container}>
            <Button title = "Update safetyCheck List" onPress = { () => this.props.navigation.navigate('CheckListScreen')}/>
            <Button title = "UpLoadImage" onPress = { () => this.props.navigation.navigate('UpLoadImageScreen')}/>
            <Button title = "UpdateGrade" onPress = { () => this.props.navigation.navigate('Electricity_UpdateScreen')}/>
            <Text style={styles4.Earthquake_resistantGrade}>
            Prev_Earthquake_resistant Grade
            </Text>
            {this.state.Earthquake_resistant.map((r, i) => (
              <View style={styles4.Earthquake_resistantState}
                    key={i}>
            <Text>{r.Earthquake_resistant}</Text>
          </View>
            ))}
        </View>
      )
    }
  }
  
  const styles4=StyleSheet.create({
    container: {
      flex:1,
      justifyContent: 'center',
      alignItems: 'center',
      backgroundColor: '#F5FCFF',
    },
    Earthquake_resistantGrade:{
      fontSize: 20,
      textAlign: 'center',
      margin: 10,
    },
    Earthquake_resistantState:{
      textAlign: 'center',
      color: '#333333',
      marginBottom: 5,
    },
  });
  





const GasStack = createStackNavigator({
  Gas : {
    screen : GasScreen
  }
});

const ElectricityStack = createStackNavigator({
  Electricity : {
    screen : ElectricityScreen
  }
});

const ElevatorStack = createStackNavigator({
  Elevator : {
    screen : ElevatorScreen
  }
});

const Earthquake_resistantStack = createStackNavigator({
  Earthquake_resistant : {
    screen : Earthquake_resistantScreen
  }
});

export default createAppContainer(createBottomTabNavigator({
  
  Gas :{
    screen : GasStack
  },
  Electricity :{
      screen : ElectricityStack
    },
  Elevator :{
      screen : ElevatorStack
    },
  Earthquake_resistant :{
      screen : Earthquake_resistantStack
    },
}, {
  defaultNavigationOptions: ({
    navigation
  }) => ({
    tabBarIcon: ({focused,tintColor}) => {
      const {routeName} = navigation.state;
      let iconName;
      if (routeName === 'Gas') {
        iconName = `ios-information-circle${focused ? '' : '-outline'}`;
      }else if (routeName === 'Electricity') {
          iconName = `ios-options${focused ? '' : '-outline'}`;
      }
      else if (routeName === 'Elevator') {
        iconName = `ios-options${focused ? '' : '-outline'}`;
      }
      else if (routeName === 'Earthquake_resistant') {
        iconName = `ios-options${focused ? '' : '-outline'}`;
      }

      // You can return any component that you like here! We usually use an
      // icon component from react-native-vector-icons
      return <Ionicons name = {iconName} size = {25}color = {tintColor}/>;
    },
  }),
  tabBarOptions: {
    activeTintColor: 'tomato',
    inactiveTintColor: 'gray',
  },
}));
