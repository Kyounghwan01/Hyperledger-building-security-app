import React from 'react';
import {createStackNavigator,
  createBottomTabNavigator,
  createAppContainer} from 'react-navigation';
  import {
    Ionicons
  } from '@expo/vector-icons';


import {
  Text,
  View,
  TextInput,
  Button,
  StyleSheet
} from 'react-native';
import Client from '../Client.js';





export default class Electricity_UpdateScreen extends React.Component {

  constructor(props) {
    super(props)
    this.state = {
      isRefreshing: false


    }

  }
  fetchGradeUpdate() {
    const facilityNumber_prev = this.props.navigation.getParam('facilityNumber_prev');
    this.state.facilityNumber_prev = this.props.navigation.getParam('facilityNumber_prev');
    this.state.safetycheck_date_prev= this.props.navigation.getParam('safetycheck_date_prev');
    const admin_prev= this.props.navigation.getParam('admin_prev');
    this.state.Electricity_prev= this.props.navigation.getParam('Electricity_prev');
    this.state.Gas_prev= this.props.navigation.getParam('Gas_prev');
    this.state.Elevator_prev= this.props.navigation.getParam('Elevator_prev');
    this.state.Earthquake_resistant_prev= this.props.navigation.getParam('Earthquake_resistant_prev');
    this.state.Final_prev= this.props.navigation.getParam('Final_prev');
    console.log(this.state.safetycheck_date_prev);
    console.log(this.state.Electricity_prev);
    
    return fetch(`http://192.168.190.16:3000/api/Grade/${facilityNumber_prev}`,
      {
        
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
        method: 'PUT',
        body: JSON.stringify({
          
            $class: "org.acme.model.Grade",
            safetycheck_date: this.state.safetycheck_date_prev,
            facilityNumber: this.state.facilityNumber_prev, 
            admin: `resource:org.acme.vehicle.auction.Vehicle#${admin_prev}`,
            Electricity: this.state.Electricity_prev,
            Gas: this.state.Gas_prev,
            Elevator: this.state.Elevator_prev,
            Earthquake_resistant: this.state.Earthquake_resistant_prev,
            Final: this.state.Final_prev
    
        })
      })
      .then(response => response.json())
      .catch(error => {
        console.error(error);
      });
  }



  render() {
    return(
        <View style={styles1.container}> 
        <View Update Electricity ></View>
        
        <Text>safetycheck_date_update</Text>
        <TextInput 
          onChangeText={(text) => { this.setState({ safetycheck_date : text }) }}></TextInput>
        <Text>Electricity_Grade_update</Text>
        <TextInput 
          onChangeText={(text) => { this.setState({ facilityNumber : text }) }}></TextInput>
        <TextInput 
          onChangeText={(text) => { this.setState({ Electricity : text }) }}></TextInput>
        <TextInput 
          onChangeText={(text) => { this.setState({ Electricity : text }) }}></TextInput>
        <TextInput 
          onChangeText={(text) => { this.setState({ Electricity : text }) }}></TextInput>                    
        <Button title="+ GradeUpdate"
          onPress={() => { this.fetchGradeUpdate().then(() => { this.props.navigation.navigate('GradeScreen') }) }}>
        </Button>
 
      </View>
    )
  }
}

const styles1=StyleSheet.create({
  container: {
    flex:1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
  }
});





/*
export default createAppContainer(createBottomTabNavigator({
  
  
  Electricity_Update :{
      screen : Electricity_UpdateStack
    }
}, {
  defaultNavigationOptions: ({
    navigation
  }) => ({
    tabBarIcon: ({focused,tintColor}) => {
      const {routeName} = navigation.state;
      let iconName;
      if (routeName === 'Electricity_Update') {
        iconName = `ios-information-circle${focused ? '' : '-outline'}`;
      }

      // You can return any component that you like here! We usually use an
      // icon component from react-native-vector-icons
      return <Ionicons name = {iconName} size = {25}color = {tintColor}/>;
    },
  }),
  tabBarOptions: {
    activeTintColor: 'tomato',
    inactiveTintColor: 'gray',
  },
}));
*/