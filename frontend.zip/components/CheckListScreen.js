import React from 'react';
import { StyleSheet, Text, View, ScrollView } from 'react-native';
// react-natvigation 라이브러리 에서 StackNavigator 추가하기
import { createStackNavigator } from 'react-navigation';
import {Constants} from 'expo';
import { FormLabel, FormInput, FormValidationMessage, Button } from 'react-native-elements';
import { CheckBox } from 'react-native-elements'



export default class App extends React.Component {
    static navigationOptions = {
        title: 'LOGIN'
    }
    constructor(props){
        super(props);
        this.state = {
            name: '',
            updateday: '',
            error: '',
            checked11:true,
            checked12:false,
            checked21:true,
            checked22:false,
            checked31:true,
            checked32:false,
            checked41:true,
            checked42:false,
        }
        
    }
    _username = (name) => {
        this.setState({ name });
    }

    _updateday = (updateday) => {
        this.setState({ updateday });
    }

  render() {
    return (
       <View style={styles.container}>
        <ScrollView>
           <Text style={styles.paragraph}> Gas 점검 체크리스트 </Text>
                <View style={styles.containerStyle}>
            
                    <FormLabel 정기 안전점검 />
                    <FormLabel>점검자 명</FormLabel>
                    <FormInput
                        value={this.state.name}
                        onChangeText={this._username}
                    />
                    
                </View>
                <View style={styles.containerStyle}>
                    <FormLabel>점검 일시</FormLabel>
                    <FormInput
                        value={this.state.updateday}
                        onChangeText={this._updateday}
                    /> 
                </View>
                <View style={styles.containerStyle}>
                    <Text style={styles.subject}>가스 시설</Text>
                </View>
                <View style={styles.containerStyle}>
                    <FormLabel>가스 누설 경보기 설치 여부</FormLabel>
                    
                    <CheckBox
                    title='적정'
                    checked={this.state.checked11}
                    onPress={() => this.setState({checked11: !this.state.checked11, checked12: !this.state.checked12})}
                    /><CheckBox
                    title='불량'
                    checked={this.state.checked12}
                    onPress={() => this.setState({checked12: !this.state.checked12, checked11: !this.state.checked11})}
                    />
                    
                </View>
                <View style={styles.containerStyle}>
                    <FormLabel>용기, 배관, 밸브 및 연소기의 파손. 변형. 노휴 또는 부식 여부</FormLabel>
                    <CheckBox
                    title='적정'
                    checked={this.state.checked21}
                    onPress={() => this.setState({checked21: !this.state.checked21, checked22: !this.state.checked22})}
                    /><CheckBox
                    title='불량'
                    checked={this.state.checked22}
                    onPress={() => this.setState({checked22: !this.state.checked22, checked21: !this.state.checked21})}
                    />
                    
                </View>
                <View style={styles.containerStyle}>
                    <FormLabel>방화 환경조성 및 주의, 경고 표시 부착 및 파손 부분 여부</FormLabel>
                    <CheckBox
                    title='적정'
                    checked={this.state.checked31}
                    onPress={() => this.setState({checked31: !this.state.checked31, checked32: !this.state.checked32})}
                    /><CheckBox
                    title='불량'
                    checked={this.state.checked32}
                    onPress={() => this.setState({checked32: !this.state.checked32, checked31: !this.state.checked31})}
                    />
                    
                </View>
                <View style={styles.containerStyle}>
                    <Text style={styles.subject}>방화 시설</Text>
                </View>
                <View style={styles.containerStyle}>
                    <FormLabel>내장재의 불연화 여부</FormLabel>
                    <CheckBox
                    title='적정'
                    checked={this.state.checked41}
                    onPress={() => this.setState({checked41: !this.state.checked41, checked42: !this.state.checked42})}
                    /><CheckBox
                    title='불량'
                    checked={this.state.checked42}
                    onPress={() => this.setState({checked42: !this.state.checked42, checked41: !this.state.checked41})}
                    />
                    
                </View>
                
                

                <View style={{marginTop : 30}}>
                    <Button
                        buttonStyle={{backgroundColor: '#2096f3'}}
                        title='제출' 
                        
                    />
                </View>

                <View style={styles.containerStyle}>
                    <FormValidationMessage>{this.state.error}</FormValidationMessage>
                </View>
                </ScrollView>
           
           
           
        </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
      justifyContent: 'center',
      paddingTop: Constants.statusBarHeight,
      backgroundColor: '#ecf0f1',
      padding: 8,
    
  },
  paragraph: {
    marginTop:70,
    margin: 30,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  containerStyle: {
    marginTop: 10
},
subject:{
    margin: 50,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
}
});